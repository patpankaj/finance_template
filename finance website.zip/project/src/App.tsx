import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Home from './pages/Home';
import StockMarket from './pages/StockMarket';
import MutualFunds from './pages/MutualFunds';
import PersonalFinance from './pages/PersonalFinance';
import TaxPlanning from './pages/TaxPlanning';
import Footer from './components/Footer';

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-gray-50">
        <Navbar />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/stock-market" element={<StockMarket />} />
          <Route path="/mutual-funds" element={<MutualFunds />} />
          <Route path="/personal-finance" element={<PersonalFinance />} />
          <Route path="/tax-planning" element={<TaxPlanning />} />
        </Routes>
        <Footer />
      </div>
    </Router>
  );
}

export default App;