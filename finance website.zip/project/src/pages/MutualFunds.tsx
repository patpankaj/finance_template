import React from 'react';
import { PieChart, Shield, TrendingUp, DollarSign } from 'lucide-react';

const MutualFunds = () => {
  return (
    <div className="pt-16">
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-green-600 to-teal-600 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl md:text-6xl font-bold text-white mb-6">
              Mutual Funds Investment
            </h1>
            <p className="text-xl text-green-100 mb-8 max-w-3xl mx-auto">
              Your guide to understanding and investing in mutual funds
            </p>
          </div>
        </div>
      </section>

      {/* Fund Types */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold mb-8">Types of Mutual Funds</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-white p-6 rounded-lg shadow-lg">
              <PieChart className="h-12 w-12 text-blue-500 mb-4" />
              <h3 className="text-xl font-bold mb-3">Equity Funds</h3>
              <p className="text-gray-600 mb-4">Investment primarily in stocks for potential high returns</p>
              <ul className="space-y-2 text-gray-600">
                <li>• Large-cap funds</li>
                <li>• Mid-cap funds</li>
                <li>• Small-cap funds</li>
                <li>• Sector funds</li>
              </ul>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-lg">
              <Shield className="h-12 w-12 text-green-500 mb-4" />
              <h3 className="text-xl font-bold mb-3">Debt Funds</h3>
              <p className="text-gray-600 mb-4">Fixed income securities for stable returns</p>
              <ul className="space-y-2 text-gray-600">
                <li>• Government securities</li>
                <li>• Corporate bonds</li>
                <li>• Money market</li>
                <li>• Liquid funds</li>
              </ul>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-lg">
              <TrendingUp className="h-12 w-12 text-purple-500 mb-4" />
              <h3 className="text-xl font-bold mb-3">Hybrid Funds</h3>
              <p className="text-gray-600 mb-4">Mix of equity and debt for balanced returns</p>
              <ul className="space-y-2 text-gray-600">
                <li>• Balanced funds</li>
                <li>• Monthly income plans</li>
                <li>• Dynamic asset allocation</li>
                <li>• Multi-asset funds</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Investment Process */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold mb-8">How to Invest</h2>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div className="bg-white p-6 rounded-lg shadow">
              <div className="text-3xl font-bold text-indigo-600 mb-4">01</div>
              <h3 className="text-xl font-semibold mb-2">KYC Registration</h3>
              <p className="text-gray-600">Complete your KYC documentation to start investing</p>
            </div>

            <div className="bg-white p-6 rounded-lg shadow">
              <div className="text-3xl font-bold text-indigo-600 mb-4">02</div>
              <h3 className="text-xl font-semibold mb-2">Choose Fund</h3>
              <p className="text-gray-600">Select mutual funds based on your investment goals</p>
            </div>

            <div className="bg-white p-6 rounded-lg shadow">
              <div className="text-3xl font-bold text-indigo-600 mb-4">03</div>
              <h3 className="text-xl font-semibold mb-2">Investment Mode</h3>
              <p className="text-gray-600">Decide between SIP or lump sum investment</p>
            </div>

            <div className="bg-white p-6 rounded-lg shadow">
              <div className="text-3xl font-bold text-indigo-600 mb-4">04</div>
              <h3 className="text-xl font-semibold mb-2">Start Investing</h3>
              <p className="text-gray-600">Begin your investment journey with regular monitoring</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default MutualFunds;