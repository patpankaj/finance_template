import React from 'react';
import { TrendingUp, BarChart2, BookOpen, Target } from 'lucide-react';

const StockMarket = () => {
  return (
    <div className="pt-16">
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-blue-600 to-indigo-600 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl md:text-6xl font-bold text-white mb-6">
              Stock Market Guide
            </h1>
            <p className="text-xl text-blue-100 mb-8 max-w-3xl mx-auto">
              Learn everything about stock market investing, from basics to advanced strategies
            </p>
          </div>
        </div>
      </section>

      {/* Learning Sections */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="bg-white p-8 rounded-xl shadow-lg">
              <TrendingUp className="h-12 w-12 text-blue-500 mb-4" />
              <h2 className="text-2xl font-bold mb-4">Stock Market Basics</h2>
              <ul className="space-y-3 text-gray-600">
                <li>• Understanding stock exchanges</li>
                <li>• How to read stock quotes</li>
                <li>• Types of stock orders</li>
                <li>• Market indices explained</li>
              </ul>
            </div>

            <div className="bg-white p-8 rounded-xl shadow-lg">
              <BarChart2 className="h-12 w-12 text-green-500 mb-4" />
              <h2 className="text-2xl font-bold mb-4">Technical Analysis</h2>
              <ul className="space-y-3 text-gray-600">
                <li>• Chart patterns</li>
                <li>• Technical indicators</li>
                <li>• Volume analysis</li>
                <li>• Trend identification</li>
              </ul>
            </div>
          </div>

          <div className="mt-8 grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="bg-white p-8 rounded-xl shadow-lg">
              <BookOpen className="h-12 w-12 text-purple-500 mb-4" />
              <h2 className="text-2xl font-bold mb-4">Fundamental Analysis</h2>
              <ul className="space-y-3 text-gray-600">
                <li>• Financial ratios</li>
                <li>• Company analysis</li>
                <li>• Industry analysis</li>
                <li>• Economic indicators</li>
              </ul>
            </div>

            <div className="bg-white p-8 rounded-xl shadow-lg">
              <Target className="h-12 w-12 text-red-500 mb-4" />
              <h2 className="text-2xl font-bold mb-4">Trading Strategies</h2>
              <ul className="space-y-3 text-gray-600">
                <li>• Day trading basics</li>
                <li>• Swing trading</li>
                <li>• Position trading</li>
                <li>• Risk management</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Market Updates */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold mb-8">Latest Market Updates</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Market update cards would go here - This is a placeholder */}
            <div className="bg-white p-6 rounded-lg shadow">
              <h3 className="font-semibold mb-2">Market Trends</h3>
              <p className="text-gray-600">Latest market trends and analysis would be displayed here.</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow">
              <h3 className="font-semibold mb-2">Top Gainers</h3>
              <p className="text-gray-600">Top performing stocks would be listed here.</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow">
              <h3 className="font-semibold mb-2">Market News</h3>
              <p className="text-gray-600">Latest market news and updates would be shown here.</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default StockMarket;