import React from 'react';
import { FileText, Calculator, Shield, Book } from 'lucide-react';

const TaxPlanning = () => {
  return (
    <div className="pt-16">
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-yellow-600 to-red-600 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl md:text-6xl font-bold text-white mb-6">
              Tax Planning Guide
            </h1>
            <p className="text-xl text-yellow-100 mb-8 max-w-3xl mx-auto">
              Optimize your tax savings with expert strategies and comprehensive planning
            </p>
          </div>
        </div>
      </section>

      {/* Tax Sections */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="bg-white p-8 rounded-xl shadow-lg">
              <FileText className="h-12 w-12 text-blue-500 mb-4" />
              <h2 className="text-2xl font-bold mb-4">Tax Deductions</h2>
              <ul className="space-y-3 text-gray-600">
                <li>• Section 80C investments</li>
                <li>• Home loan benefits</li>
                <li>• Health insurance premium</li>
                <li>• Education expenses</li>
              </ul>
            </div>

            <div className="bg-white p-8 rounded-xl shadow-lg">
              <Calculator className="h-12 w-12 text-green-500 mb-4" />
              <h2 className="text-2xl font-bold mb-4">Tax Calculation</h2>
              <ul className="space-y-3 text-gray-600">
                <li>• Income tax slabs</li>
                <li>• Tax calculation methods</li>
                <li>• Advance tax planning</li>
                <li>• Tax saving calculator</li>
              </ul>
            </div>
          </div>

          <div className="mt-8 grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="bg-white p-8 rounded-xl shadow-lg">
              <Shield className="h-12 w-12 text-purple-500 mb-4" />
              <h2 className="text-2xl font-bold mb-4">Tax Saving Investments</h2>
              <ul className="space-y-3 text-gray-600">
                <li>• ELSS mutual funds</li>
                <li>• PPF account</li>
                <li>• National Pension Scheme</li>
                <li>• Tax-saving FDs</li>
              </ul>
            </div>

            <div className="bg-white p-8 rounded-xl shadow-lg">
              <Book className="h-12 w-12 text-red-500 mb-4" />
              <h2 className="text-2xl font-bold mb-4">Tax Filing Guide</h2>
              <ul className="space-y-3 text-gray-600">
                <li>• ITR filing process</li>
                <li>• Required documents</li>
                <li>• Common mistakes to avoid</li>
                <li>• Due dates and penalties</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Tax Tips */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold mb-8">Tax Planning Tips</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-white p-6 rounded-lg shadow">
              <h3 className="text-xl font-semibold mb-4">Start Early</h3>
              <p className="text-gray-600">
                Begin tax planning at the start of the financial year to maximize benefits.
              </p>
            </div>

            <div className="bg-white p-6 rounded-lg shadow">
              <h3 className="text-xl font-semibold mb-4">Document Management</h3>
              <p className="text-gray-600">
                Maintain proper documentation of all tax-saving investments and expenses.
              </p>
            </div>

            <div className="bg-white p-6 rounded-lg shadow">
              <h3 className="text-xl font-semibold mb-4">Regular Review</h3>
              <p className="text-gray-600">
                Periodically review your tax planning strategy to optimize savings.
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default TaxPlanning;