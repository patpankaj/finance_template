import React from 'react';
import MarketAnalysis from '../components/MarketAnalysis';
import InvestmentSection from '../components/InvestmentSection';
import InsuranceSection from '../components/InsuranceSection';
import Calculator from '../components/Calculator';

const Home = () => {
  return (
    <div>
      {/* Hero Section */}
      <section id="home" className="pt-20 pb-16 bg-gradient-to-r from-indigo-600 to-purple-600">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-16">
          <div className="text-center">
            <h1 className="text-4xl md:text-6xl font-bold text-white mb-6">
              Your Financial Future Starts Here
            </h1>
            <p className="text-xl text-indigo-100 mb-8 max-w-3xl mx-auto">
              Comprehensive financial solutions for smart investments, market analysis, and insurance planning
            </p>
            <div className="flex justify-center space-x-4">
              <a
                href="#markets"
                className="bg-white text-indigo-600 px-8 py-3 rounded-lg font-semibold hover:bg-indigo-50 transition-colors"
              >
                Explore Markets
              </a>
              <a
                href="#calculator"
                className="bg-transparent border-2 border-white text-white px-8 py-3 rounded-lg font-semibold hover:bg-white hover:text-indigo-600 transition-colors"
              >
                Try Calculator
              </a>
            </div>
          </div>
        </div>
      </section>

      <MarketAnalysis />
      <InvestmentSection />
      <InsuranceSection />
      <Calculator />
    </div>
  );
};

export default Home;