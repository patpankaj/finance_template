import React from 'react';
import { Wallet, PiggyBank, CreditCard, BarChart } from 'lucide-react';

const PersonalFinance = () => {
  return (
    <div className="pt-16">
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-purple-600 to-pink-600 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl md:text-6xl font-bold text-white mb-6">
              Personal Finance Management
            </h1>
            <p className="text-xl text-purple-100 mb-8 max-w-3xl mx-auto">
              Take control of your finances with expert guidance and practical tips
            </p>
          </div>
        </div>
      </section>

      {/* Financial Planning */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold mb-8">Financial Planning</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="bg-white p-6 rounded-lg shadow-lg">
              <Wallet className="h-12 w-12 text-blue-500 mb-4" />
              <h3 className="text-xl font-bold mb-3">Budgeting</h3>
              <ul className="space-y-2 text-gray-600">
                <li>• Income tracking</li>
                <li>• Expense management</li>
                <li>• Savings goals</li>
                <li>• Budget templates</li>
              </ul>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-lg">
              <PiggyBank className="h-12 w-12 text-green-500 mb-4" />
              <h3 className="text-xl font-bold mb-3">Savings</h3>
              <ul className="space-y-2 text-gray-600">
                <li>• Emergency fund</li>
                <li>• Savings strategies</li>
                <li>• Goal-based saving</li>
                <li>• Investment options</li>
              </ul>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-lg">
              <CreditCard className="h-12 w-12 text-purple-500 mb-4" />
              <h3 className="text-xl font-bold mb-3">Debt Management</h3>
              <ul className="space-y-2 text-gray-600">
                <li>• Debt reduction</li>
                <li>• Credit score</li>
                <li>• Loan management</li>
                <li>• Debt consolidation</li>
              </ul>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-lg">
              <BarChart className="h-12 w-12 text-red-500 mb-4" />
              <h3 className="text-xl font-bold mb-3">Wealth Building</h3>
              <ul className="space-y-2 text-gray-600">
                <li>• Asset allocation</li>
                <li>• Portfolio management</li>
                <li>• Retirement planning</li>
                <li>• Estate planning</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Financial Tips */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold mb-8">Smart Money Tips</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-white p-6 rounded-lg shadow">
              <h3 className="text-xl font-semibold mb-4">50/30/20 Rule</h3>
              <p className="text-gray-600">
                Allocate 50% of income to needs, 30% to wants, and 20% to savings and investments.
              </p>
            </div>

            <div className="bg-white p-6 rounded-lg shadow">
              <h3 className="text-xl font-semibold mb-4">Emergency Fund</h3>
              <p className="text-gray-600">
                Maintain 3-6 months of expenses in an easily accessible emergency fund.
              </p>
            </div>

            <div className="bg-white p-6 rounded-lg shadow">
              <h3 className="text-xl font-semibold mb-4">Debt Management</h3>
              <p className="text-gray-600">
                Prioritize high-interest debt repayment while maintaining minimum payments on others.
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default PersonalFinance;