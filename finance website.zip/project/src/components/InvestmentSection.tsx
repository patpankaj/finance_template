import React from 'react';
import { Briefcase, PieChart, TrendingUp, Shield } from 'lucide-react';

const InvestmentSection = () => {
  return (
    <section id="investments" className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl font-bold text-gray-900 mb-8">Investment Opportunities</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="bg-gradient-to-br from-indigo-500 to-purple-600 p-8 rounded-xl text-white">
            <Briefcase className="h-12 w-12 mb-4" />
            <h3 className="text-2xl font-bold mb-4">Portfolio Management</h3>
            <p className="mb-4">Expert guidance on diversifying your investment portfolio for optimal returns.</p>
            <button className="bg-white text-indigo-600 px-6 py-2 rounded-lg font-semibold hover:bg-opacity-90 transition-colors">
              Learn More
            </button>
          </div>
          
          <div className="bg-gradient-to-br from-blue-500 to-teal-400 p-8 rounded-xl text-white">
            <PieChart className="h-12 w-12 mb-4" />
            <h3 className="text-2xl font-bold mb-4">Asset Allocation</h3>
            <p className="mb-4">Strategic distribution of investments across different asset classes.</p>
            <button className="bg-white text-blue-600 px-6 py-2 rounded-lg font-semibold hover:bg-opacity-90 transition-colors">
              Explore
            </button>
          </div>
        </div>

        <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="p-6 bg-gray-50 rounded-lg">
            <TrendingUp className="h-8 w-8 text-green-500 mb-4" />
            <h4 className="text-xl font-semibold mb-2">Growth Stocks</h4>
            <p className="text-gray-600">High-potential stocks for long-term growth</p>
          </div>
          
          <div className="p-6 bg-gray-50 rounded-lg">
            <Shield className="h-8 w-8 text-blue-500 mb-4" />
            <h4 className="text-xl font-semibold mb-2">Fixed Income</h4>
            <p className="text-gray-600">Stable returns through bonds and securities</p>
          </div>
          
          <div className="p-6 bg-gray-50 rounded-lg">
            <PieChart className="h-8 w-8 text-purple-500 mb-4" />
            <h4 className="text-xl font-semibold mb-2">Mutual Funds</h4>
            <p className="text-gray-600">Professionally managed investment pools</p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default InvestmentSection;