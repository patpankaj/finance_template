import React from 'react';
import { TrendingUp, TrendingDown, DollarSign, Bitcoin, LineChart } from 'lucide-react';

const MarketAnalysis = () => {
  return (
    <section id="markets" className="py-16 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl font-bold text-gray-900 mb-8">Market Analysis</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <div className="bg-white p-6 rounded-lg shadow-lg">
            <div className="flex items-center mb-4">
              <TrendingUp className="h-6 w-6 text-green-500 mr-2" />
              <h3 className="text-xl font-semibold">Stock Markets</h3>
            </div>
            <p className="text-gray-600">Real-time analysis of global stock markets and indices.</p>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-lg">
            <div className="flex items-center mb-4">
              <Bitcoin className="h-6 w-6 text-orange-500 mr-2" />
              <h3 className="text-xl font-semibold">Cryptocurrency</h3>
            </div>
            <p className="text-gray-600">Latest trends and insights in the crypto market.</p>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-lg">
            <div className="flex items-center mb-4">
              <DollarSign className="h-6 w-6 text-blue-500 mr-2" />
              <h3 className="text-xl font-semibold">Forex</h3>
            </div>
            <p className="text-gray-600">Currency exchange rates and forex market analysis.</p>
          </div>
        </div>
        
        <div className="mt-12 bg-white p-6 rounded-lg shadow-lg">
          <div className="flex items-center mb-4">
            <LineChart className="h-6 w-6 text-indigo-500 mr-2" />
            <h3 className="text-xl font-semibold">Market Overview</h3>
          </div>
          <div className="h-64 bg-gray-100 rounded-lg flex items-center justify-center">
            <p className="text-gray-500">Market chart visualization would go here</p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default MarketAnalysis;