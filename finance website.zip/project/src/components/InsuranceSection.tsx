import React from 'react';
import { Heart, Home, Car, Umbrella } from 'lucide-react';

const InsuranceSection = () => {
  return (
    <section id="insurance" className="py-16 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl font-bold text-gray-900 mb-8">Insurance Plans</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="bg-white p-6 rounded-lg shadow-lg hover:shadow-xl transition-shadow">
            <Heart className="h-10 w-10 text-red-500 mb-4" />
            <h3 className="text-xl font-semibold mb-2">Health Insurance</h3>
            <p className="text-gray-600 mb-4">Comprehensive health coverage for you and your family</p>
            <ul className="text-sm text-gray-500 space-y-2">
              <li>✓ Medical expenses</li>
              <li>✓ Prescription drugs</li>
              <li>✓ Preventive care</li>
            </ul>
          </div>
          
          <div className="bg-white p-6 rounded-lg shadow-lg hover:shadow-xl transition-shadow">
            <Home className="h-10 w-10 text-blue-500 mb-4" />
            <h3 className="text-xl font-semibold mb-2">Home Insurance</h3>
            <p className="text-gray-600 mb-4">Protect your home and belongings</p>
            <ul className="text-sm text-gray-500 space-y-2">
              <li>✓ Property damage</li>
              <li>✓ Theft protection</li>
              <li>✓ Liability coverage</li>
            </ul>
          </div>
          
          <div className="bg-white p-6 rounded-lg shadow-lg hover:shadow-xl transition-shadow">
            <Car className="h-10 w-10 text-green-500 mb-4" />
            <h3 className="text-xl font-semibold mb-2">Auto Insurance</h3>
            <p className="text-gray-600 mb-4">Complete protection for your vehicle</p>
            <ul className="text-sm text-gray-500 space-y-2">
              <li>✓ Collision coverage</li>
              <li>✓ Liability protection</li>
              <li>✓ Roadside assistance</li>
            </ul>
          </div>
          
          <div className="bg-white p-6 rounded-lg shadow-lg hover:shadow-xl transition-shadow">
            <Umbrella className="h-10 w-10 text-purple-500 mb-4" />
            <h3 className="text-xl font-semibold mb-2">Life Insurance</h3>
            <p className="text-gray-600 mb-4">Secure your family's future</p>
            <ul className="text-sm text-gray-500 space-y-2">
              <li>✓ Term life coverage</li>
              <li>✓ Whole life plans</li>
              <li>✓ Investment options</li>
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
};

export default InsuranceSection;